package altorithm;

import java.util.Scanner;

public class IntStackTester {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        IntStack stack = new IntStack(64);

        while(true){
            System.out.println("=================================================");
            System.out.printf("현재 데이터 개수: %d / %d\n", stack.capaticy(), stack.size());
            System.out.print("(1)푸시　(2)팝　(3)피크　(4)덤프　(0)종료: ");

            int menu = scanner.nextInt();
            if (menu ==0) break;

            int data;

            switch(menu){
                case 1->{
                    data = scanner.nextInt();
                    stack.push(data);
                    System.out.printf("데이터 : %d", data);
                }
                case 2->{
                    System.out.printf("pop한 데이터는 %d 입니다.\n",  stack.pop());
                }
                case 3->{
                    System.out.printf("peak한 데이터는 %d 입니다\n", stack.top());
                    break;
                }
                case 4->{
                    stack.dump();
                    break;
                }
            }
        }
    }
}

