package altorithm;

public class IntStack {
    private int capacity;
    private int stack[];
    private int top;

    IntStack(int capacity) {
        this.capacity = capacity;
        this.stack = new int[capacity];
    }

    public boolean push(int num) {
        if (full()) return false;

        stack[top++] = num;
        return true;
    }

    boolean full() {
        return top == capacity;
    }

    public int pop() {
        if (empty()) return -1;
        return stack[--top];
    }

    boolean empty() {
        return top == 0;
    }

    public int top() {
        if(empty()) return -1;
        return stack[top-1];
    }

    public int size() {
        return top;
    }

    public int capaticy() {
        return capacity;
    }

    public void clear() {
        top=0;
    }

    public void dump() {
        if(empty()){
            System.out.printf("stack이 비어있습니다.\n");
        }
        else{
            for(int i =0;i<top;i++)
                System.out.printf("%d ", stack[i]);
        }
    }

}
